package com.veilas.reductionlinks;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.motion.utils.HyperSpline;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private EditText full_link, red_link;
    private Button btn_link;
    private ArrayAdapter<String> arrayAdapter;
    private ArrayList<String> arrayList;
    private SharedPreferences spBase;
    private ListView red_list;
    private TextView text_label_row;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        full_link = findViewById(R.id.full_link);
        red_link = findViewById(R.id.red_link);
        btn_link = findViewById(R.id.btn_link);
        red_list = findViewById(R.id.red_list);
        text_label_row = findViewById(R.id.text_label_row);
        spBase = getPreferences(MODE_PRIVATE);


        btn_link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (full_link.getText().toString().length() < 3) {
                    btn_link.setText("НЕВЕРНАЯ ССЫЛКА");

                } else if (red_link.getText().toString().length() < 2) {
                    btn_link.setText("СОКРАЩЕННАЯ ССЫЛКА");

                } else {
                    btn_link.setText("ГОТОВО");

                    if(!arrayAdapter.equals(arrayAdapter)) {
                        btn_link.setText("УКАЖИТЕ ДРУГУЮ СОКРАЩЕННУЮ ССЫЛКУ");
                    }else{
                        arrayList.add(String.valueOf(red_link.getText()));
                    }

                }
            }
        });

        arrayList = new ArrayList<>();
        arrayList.add(red_list.toString());
        red_link.

        arrayAdapter = new ArrayAdapter<String>(MainActivity.this, R.layout.list, R.id.text_label_row, arrayList);
        red_list.setAdapter(arrayAdapter);
    }

    public void saveLinks() {



        SharedPreferences.Editor editor = spBase.edit();
        editor.putString("links", String.valueOf(red_link.getText()));
        editor.apply();
    }


    void ArrayLink(){


    }
}




